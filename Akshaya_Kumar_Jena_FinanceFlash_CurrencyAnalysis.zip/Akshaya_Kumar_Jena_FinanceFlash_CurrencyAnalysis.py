import requests
from bs4 import BeautifulSoup
import pandas as pd
import matplotlib.pyplot as plt

# Function to scrape currency data from Yahoo Finance
def scrape_currency_data(url):
    # response = requests.get(url)
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'
        }

    response = requests.get(url, headers=headers)
    if response.status_code == 200:
        soup = BeautifulSoup(response.text, 'html.parser')
        table = soup.find('table', class_='W(100%) M(0)')
        headers = table.find_all('th')
        headers = [header.text for header in headers]
        rows = table.find_all('tr')[1:-1]
        dates = []
        closing_prices = []
        for row in rows:
            data = row.find_all('td')
            date = data[0].text
            closing_price = data[4].text
            dates.append(date)
            closing_prices.append(closing_price)
        currency_df = pd.DataFrame({
            'Date': dates,
            'Closing Price': closing_prices
        })
        return currency_df
    else:
        print('Failed to retrieve data. Status code:', response.status_code)
        return None

# Function to perform technical analysis
def perform_technical_analysis(currency_data):

    # Convert the 'Closing Price' column to numeric
    currency_data['Closing Price'] = pd.to_numeric(currency_data['Closing Price'], errors='coerce')

    # Calculate Moving Average (MA)
    currency_data['MA'] = currency_data['Closing Price'].rolling(window=20).mean()

    # Calculate Bollinger Bands (BB)
    # Bollinger Bands consist of a moving average (MA) and two standard deviations (SD) away from the MA
    currency_data['SD'] = currency_data['Closing Price'].rolling(window=20).std()
    currency_data['Upper Band'] = currency_data['MA'] + 2 * currency_data['SD']
    currency_data['Lower Band'] = currency_data['MA'] - 2 * currency_data['SD']

    # Calculate Commodity Channel Index (CCI)
    # CCI measures the difference between the current price and its historical average, relative to the average deviation from the average
    typical_price = (currency_data['Closing Price'] + currency_data['Closing Price'] + currency_data['Closing Price']) / 3
    mean_deviation = (typical_price - typical_price.rolling(window=20).mean()).abs().rolling(window=20).mean()
    currency_data['CCI'] = (typical_price - typical_price.rolling(window=20).mean()) / (0.015 * mean_deviation)

    # Now, currency_data DataFrame contains 'MA', 'Upper Band', 'Lower Band', and 'CCI' columns as technical indicators


# Function to make decisions based on technical indicators
def make_decisions(currency_data):
    # Your decision-making code here
    def make_decision(row):
        if row['Closing Price'] > row['MA'] and row['Closing Price'] < row['Upper Band'] and row['CCI'] > -100:
            return 'BUY'
        elif row['Closing Price'] < row['MA'] and row['Closing Price'] > row['Lower Band'] and row['CCI'] < 100:
            return 'SELL'
        else:
            return 'NEUTRAL'

    # Apply decision-making function to each row
    currency_data['Decision'] = currency_data.apply(make_decision, axis=1)

    # Display the resulting DataFrame
    print(currency_data)


# Main function to orchestrate the entire process
def main():
    # URL of the Yahoo Finance page containing historical EUR/INR currency data
    url = 'https://finance.yahoo.com/quote/EURINR%3DX/history?p=EURINR%3DX'

    # Scrape currency data
    currency_data = scrape_currency_data(url)

    if currency_data is None:
        print("Failed to retrieve currency data.")
        return

    # Perform technical analysis
    perform_technical_analysis(currency_data)

    # Make decisions based on technical indicators
    make_decisions(currency_data)
    # Apply decision-making function to each row


    # Visualization code if needed
    # Example: Plotting the data
    plt.plot(currency_data['Date'], currency_data['Closing Price'])
    plt.title('EUR/INR Currency Analysis')
    plt.xlabel('Date')
    plt.ylabel('Closing Price')
    plt.xticks(rotation=45)
    plt.grid(True)
    # plt.show()

if __name__ == "__main__":
    main()
